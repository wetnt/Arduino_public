
                             NMEA statistics utility

                              NMEASTAT.exe Ver1.04

                               Dec. 2009 (C)4river

Summary.

  NMEASTAT calculates and displays 2drms etc. reading the NMEA log file of the GPS receiver. 

  Operating condition.
     Operational OS: Windows 7, Windows Vista, Windows XP.


Feature.
  1) The horizontal, horizontal south-north, horizontal east-west, and altitude 2drms are 
     calculating displayed.
  2) The mean value in the latitude longitude and the altitude is displayed.
  3) The read data can be output as CSV file.


Install.
  In installation just copies executable file NMEASTAT.exe in the suitable folder.
  Because registry is not used, it can Un-install with only the deletion of NMEASTAT.exe and
  NMEASTAT.ini

  Note1) It is not possible to write it under the Program Files folder in Windows Vista.
         If possible, please install NMEASTAT.exe in a folder besides "Program Files".


Usage.

 1. Reading of NMEA log file. 

    The extension of the NMEA log file is either ".nmea", ".nme", ".nma" or ".txt". 
    TReading of a logfile can be performed by the following 3 ways.
    1) It reads from an open dialog by main menu "File" -> "Load file". 
    2) It reads by drag & drop. 
    3) The file fixed by the command line option when starting is read. 

 2. Option of graphical representation

    Monotone: The plot is done in the solid black when checking it. 
              The gradation is displayed at the appearance frequency when not checking it.
    Tick dot: The dot is displayed by nine dots when checking it.
              It displays it by one dot when not checking it.

 3. Content of display

    2drms
      Horizontal:  2drm horizontal value is displayed. 
      Altitude:    2drm value of the altitude is displayed. 
      East-West:   2drms value only of the direction of east-west is displayed.
      North-South: 2drms value only of the direction of south-north is displayed. 

    Average
      Latitude:  The mean value of latitude is displayed.
      Longitude: The mean value of longitude is displayed.
      Altitude:  The mean value of altitude is displayed. 
      DGPS:      The ratio that measures DGPS is displayed with %.

    Statistics
      Mean values, minimum values and the maximum values of HDOP, VDOP, PDOP and the number of 
      use satellites are displayed.

    Graphical representation
      A horizontal position is plotted. 
      The center is a mean value, and the azimuth becomes the N, E, S, W from the upper part 
      clockwise. 
      The scale can be changed from 0.1m to 500m by a Up-Down button of the lower right.

 4. Output of result

    The output can be specified from the main menu.
    File -> Print form: A form screen is printed on the printer by the bit map.
    File -> Copy Form:  A form screen is copied onto the clipboard by the bit map. 
    File -> Print Text: Data is printed on the printer in the text.
    File -> Copy Text:  Data is copied onto the clipboard by the text.

    Operation that the right-click of the mouse on form is also the same can be performed.

 5. Output of CSV file

    The Reduce dialog is displayed with "File" -> "Save to CSV". 
    It thins out according to the condition when the condition is set and the "Reduce" button 
    is clicked and it outputs it.
    All data is output disregarding the condition when the "All" button is clicked. 

 6. Commandline option.

    The specified file is processed by specifying the NMEA log file.
    An arbitrary option file is applicable by the specification of the configuration file.
    The extension of the configuration file is limited to ".ini".
      Ex) NMEASTAT test.nmea

    When the blank is included in path or the file name, it is necessary to enclose it with
    double quotes(").
      Ex) NMEASTAT "C:\Documents and Settings\User\test.nmea"

 6. Drag & drop.
 
    The NMEA log file and the configuration file are processed and an arbitrary log file can be
    processed to the execution file icon or the form by dragging it.

 7. Configuration file (NMEASTAT.ini)

   The options setting when ending is preserved in NMEASTAT.ini of the same to execution 
   file folder. 
   Two or more configuration files are preserved and it is possible to select it with 
   the command line or the drug & drop. 
   When the folder with the configuration file is read-only, it copies onto folder 
   %APPDATA%\NMEASTAT\ and it uses it. 
   %APPDATA% is a folder displayed to input by the DOS prompt as "echo %APPDATA%" <Enter>.

  1) [Option] Section
     The option setting, the reading folder, and the display position are preserved.
       DataPath: Reading folder.
       Ext:      List of correspondence extension name.

  2) [Font] Section
     Information on the display font is preserved.
     The change by the user is also possible. 

     Initial values of font specification other than Japanese.
       EngCharset=0
       EngFontName=Courier New
       EngFontSize=9

     Initial value of Japanese font.
       JpCharset=1
       JpFontName=�l�r �S�V�b�N
       JpFontSize=10


Limitations and notes.

  1) A correct value cannot be displayed by the data of the high latitude region in the vicinity
     of the pole.
  2) Long measured data at the open fixed location of the sky is necessary for calculation of 2drms.
     GPS satellites to go around the earth in about 24 hours, it's desirable to prepare NMEA log
     for 24 hours.
  3) Since satellite arrangement changes by the region and latitude to be used, the value of 2drms 
     is also changed.


Used compiler and component.

    In compiler used
      CodeGear Delphi 2007 Professional(Delphi for Win32)   Borland Software Corp.


Release note.

 * This application is the free software.
 * It does not prohibit redistribution, but *.txt and NMEASTAT.exe including the set of distribution.
 * The author takes no responsibility to any losses and obstacles which were produced by use or
   distribution of this application.


Version history.

  Ver1.04 Dec. 2009
    1. It corresponds to extension name ".nma".
       The correspondence extension name was able to be specified by the configuration file.
    2. The "Reduce" form was displayed at the center of the main form.
    3. The dialog was displayed at the center of the form.

  Ver1.03 Mar. 2008
    1. A defect of MemoryStream processing was corrected.
    2. Scale preservation reading of a track graph was corrected.
    3. The indication point of Reduce dialogue was made the desktop center.

  Ver1.02 Mar. 2008
    1. The thinning out function of the CSV output was added. 
    2. In order to be able to process with NMEA2KMZ, the item name of 1st line of CSV output 
       was modified.

  Ver1.01 Feb. 2008
    1. Added a CSV file output function.
    2. Measures when the configuration file was in a read-only folder were added.
    3. The processing of the parameter of E/W in the longitude of the GGA sentence was corrected. 

  Ver1.00beta Sep. 2007 Beta editions.

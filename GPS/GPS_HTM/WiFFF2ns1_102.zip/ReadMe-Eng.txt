
                          WiFiFoFum to NetStumbler file converter.

                                    WiFFF2ns1.exe Ver1.02

                            Jan. 2007 (C)4river @nifty PGB01551

1. Summary

    From the Log file (*.XML) and GPS Log-file(*.TXT) of "WiFiFofum" The file for 
    "NetStumbler"(*.ns1) is created.

    Since the discrete point information on GPS has not been included in the output file 
    of WiFiFoFum.
    Using this software, it can make the *.ns1 file for NetStumbler which includes GPS 
    information.

    Main feature

    * Including GPS log information to the *.ns1 file, it outputs.
    * It seeks best position from the GPS log file and revises the data from the *.XML 
      data and outputs to the *.ns1 file.
    * When the maximum level of "Sig" plural it exists, seeking each mean value of 
      latitude and longitude, it makes best position.
    * The *.XML file can be converted to the *.ns1 file even with when there is no GPS 
      log file.
      In this case it does not include GPS information and it does not revise best 
      position.


2. Installation

    Installation just copies executable file WiFFF2ns1.exe in the suitable folder.
    Because the registry is not used, it is possible to uninstall it by deleting 
    "WiFFF2ns1.exe" and "WiFFF2ns1.ini". 


3. Operating condition

    Operational OS : Windows XP


4. Usage

    Conversion begins when the "Excecute" button is clicked after "WiFFF2ns1.exe" is 
    started and "XML file", "GPS log", "Output file" are specified. 
    Clicking "Browse" button, when it appoints in the retention dialogue, when it 
    clicks "OK", it starts conversion.
    When size of the GPS log file is large, time becomes long in conversion.
    Progress is reported underneath the progress bar.
    When "Completed." is indicated, "GPS_Log/XML" value of the numerator is small, 
    being to be a possibility without of being the pair where the *.XML file and 
    the GPS log file are correct please verify.
    Conversion can be aborted by pushing "Esc" key.

     Note) As for the default folder when care power it does file name, the 
           Initial-folder of each Open/Save dialogue is used.
           Please input it by the absolute path when you want to specify an original 
           folder. 

    Procedure to preserve GPS-log with WiFiFoFum (PDA side).
     1) The "Apply" button is clicked after inputting the head portion of a file name 
        as Path saved in the column of "Autosave filename prefix with path." after  
        "Tools" -> "Option".
     2) After "tools" is clicked, the check mark is applied to "Autosave(If GPS valid)". 
     3) The page of "GPS" is selected by "tools" -> "Optios..". 
        The serial port is opened clicking "Open" after "Port" and "Baud" are selected. 

     Note) There is no necessity of the re-setting if 1) and 2) set the above-mentioned 
           once. 
           3) There is a necessity set whenever WiFiFoFum is started when the GPS-log is 
           the necessary. 


5. Setup file (WiFFF2ns1.ini)

    When it starts first time, configuration file "WiFFF2ns1.ini" is made for the same to 
    execution file folder. 
    It is possible to correct it if necessary. 


  1)Section of [Option]

    A form position, the size, the font specification, and the default folder, etc. 
    are preserved. 


  2)Section of [XmlIdent]

    The Tag name of Log file(*.XML) of WiFiFofum is specified. 
    The part of the blank specifies the value and when the support tag will increase 
    in the future, can specify the tag definition. 
    The capital letter and small letter of a Tag identify in the same category.

    Because the expressive form of the value of the "Channels" tag is uncertain, three 
    kinds of following options are prepared. 
    Please define only corresponding one. 

      ChannelsI : It uses it when expressed by a single decimal number. 
                   Ex) If XML is <Channels>1026</Channels>, 
                       it is described ChannelsI=<Channels>. 
      ChannelsH : It uses it when expressed by a single hexadecimal number. 
                   Ex) If XML is <Channels>0402</Channels>, 
                       it is described ChannelsH=<Channels>. 
      ChannelsM : It uses, when expressed by comma separated decimal numbers.
                   Ex) If XML is <Channels>1,10</Channels>, 
                       it is described ChannelsM=<Channels>. 


  3)Section of [GpsIdent]

    The header of a GPS log file(*.TXT) is specified.
    The portion with a blank value can specify a header, when a header increases in the 
    future.
    The capital letter and small letter of a Tag identify in the same category.
    However, it is changed and saved to a capital letter.


  4)Section of [Default]

     Specification of default is retained.
     SigBias : It is numerical value in order to convert Sig and Noise of the GPS log file
      (-149).

     Default value when there is no data in the log-file is appointed.
     NumSats :  NumSats value of *.ns1 file (3).
     MinNiose : MinNoise value of *.ns1 file (4).
     MaxSNR :   MaxSNR value of *.ns1 file (4).
     BeaconInterval : BeaconInterval value of *.ns1 file (100).


6. Transform technique

  1) APINFO
     SSID            XML.SSID or VML.SSID_SP
     BSSID           XML.MAC
     MaxSignal       XML.MaxRSSI    *1
     MinNoise        (XML.MinNoise) or Option.MinNiose
     MaxSNR          (XML.MaxSNR) or Option.MaxSNR
     Flags           XML.WEP and TYPE
     BeaconInterval  (XML.BeaconInterval) or Option.BeaconInterval
     FirstSeen       XML.FirstSeen  *2
     LastSeen        XML.LastSeen   *2
     BestLat         XML.Lat
     BestLong        XML.Lon
     Name            (XML.Name)
     Channels        (XML.Channels) *3
     LastChannel     XML.Channel
     IPAddress       (XML.IPAddress)
     MinSignal       XML.RSSI
     MaxNoise        (XML.MaxNoise)
     DataRate        (XML.DataRate)
     IPSubnet        (XML.IPSubnet)
     IPMask          (XML.IPMask)
     ApFlags         (XML.ApFlags)

      *1. It substitutes at the most "Signal" of APDATA.
      *2. Subtraction doing the offset part, it converts to UTC.
      *3. The value which is formed from LastChannel is appended.

  2) APDATA
     Time            GpsLog.Time             
     Signal          GpsLog.SNR_Sig_Noise.Sig + Option.SigBias
     Noise           GpsLog.SNR_Sig_Noise.Noise + Option.SigBias   *3

      *3. If the value of GpsLog.SNR_Sig_Noise.Noise 0, -100 is set.

  3) GPSDATA
     Latitude        GpsLog.Lat
     Longitude       GpsLog.Lon
     Altitude        (GpsLog.Altitude)
     NumSats         (GpsLog.NumSats) or Option.NumSats
     Speed           (GpsLog.Speed)
     Track           (GpsLog.Track)
     MagVariation    (GpsLog.MagVariant)
     Hdop            (GpsLog.Hdop) or XML.HDOP 

  Note)  () displays the undefined data at present time (It can define with setting 
         file "WiFFF2ns1.ini").
           XML.<X>    : Data item X of XML file.
           GpsLog.<X> : Data item X of GPS log file.
           Option.<X> : Set by configuration file "WiFFF2ns1.ini" content X


7. Used compiler

    In compiler used
      Delphi 2006 Professional(Delphi for Win32)   Borland Software Corp.


8. Link

   Aspecto Software
     WiFiFoFum : http://www.aspecto-software.com/xoops/

   NetStumbler.com
     NetStumbler : http://www.netstumbler.com/

   stumbler dot net
     How to read and write .NS1 files: http://www.stumbler.net/ns1files.html


Release note.

 * This application is the free software.
 * It does not prohibit redistribution, but *.TXT and WiFFF2ns1.exe including the 
   set of distribution.
 * The author takes no responsibility to any losses and obstacles which were produced by 
   use or distribution of this application.


Version history.

  Ver1.02 Jan. 2007
    1. It handling to Locales other than English and Japanese.

  Ver1.01 Jun. 2006
    1. As date time is included in Time of APDATA, it corrected.

  Ver1.00 May. 2006  First editions.

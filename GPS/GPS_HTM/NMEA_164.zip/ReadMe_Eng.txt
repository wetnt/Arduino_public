
                              GPS NMEA monitor for Windows.

                                    NMEA.EXE Ver1.64

                                   Jul. 2011 (C)4river
                            http://homepage2.nifty.com/k8/gps/

1. Summary.

 1)Main features.
   * Decoding the NMEA sentence of 11 types, to understand it displays in real time easily.
   * Sentence of specification and the sentence which is not supported can be displayed 
     with the text.
   * The sentence which has checksum error and the like can be displayed with the text.
   * Graphical representation Sky-plot and SNR.
   * It displays the mean value of latitude and longitude and altitude.
   * Calculating 2drms, it displays.
   * Optional command can be forwarded to GPS.
     Calculating checksum automatically, it adds (as a calculator of checksum it can 
     utilize).
     It can record the command which it forwards every type of GPS up to 100, can reuse.
     Also transmission of the binary code is possible.
     Checksum is added to SiRF and UBX binary command automatically.
   * The NMEA data which it receives can be retained in the text file.
   * It can play back can display the NMEA log file.
     Playback fast forward and step playback being possible, playback of reverse direction 
     is possible.
     The playback point can be configurated optionally with the drag of the track bar.
     The playback data can be output to the serial port.
   * The UTC time of GPS and time difference of the personal computer can be displayed in 
     real time.
   * Change of UTC time of RMC sentence is monitored, the report is displayed in when it 
     fluctuated.
     It can monitor Missing the sentence.  and leap second correcting after the cold 
     starting.
   * The elapsed time which fix after sending out the GPS command of Cold start etc., can 
     be displayed.
   * It can display GSA and GSV sentence to 16 satellites.
   * Indicatory language can designate change as Japanese and English.

 2) Install.
   In installation just copies executable file NMEA.EXE and NMEA.INI in the suitable folder.
   Because registry is not used, it can Un-install with only the deletion of NMEA.EXE and 
   NMEA.INI.

    Note1) When old version is used, NMEA.EXE only to overwrite copy, according to need 
           NMEA.INI the GPS command and the like of please merge.
           In initial condition being to become English mode, "Langage" -> "Japanese" it 
           becomes Japanese indication.
           Please rename "NMEA_Jp.INI" to "NMEA.INI" to use the setting file of the 
           Japanese notation ("NMEA.INI" is renamed to "NMEA_Eng.INI" etc. in advance).

    Note2) When "compatibility mode" is set as "Windows XP (Service Pack2)" by a property 
           of an executable file or a short cut in Windows Vista, it becomes possible to 
           detect an effective serial port.

    Note3) With "Windows Vista" Administrator is necessary in correction of time.
           When "Run this program as an administrator" check is inserted with the 
           executable file or the property of shortcut, it reaches the point where 
           being promoted dialogue to Administrator is indicated in when starting.

    Note4) When GPS is USB or Bluetooth connection, the driver's installation is necessary.

 3) Operating condition.
     Operational OS:      Windows Vista, Windows XP, Windows 2000.
     RS-232C baud rate:   300 to 115,200bps.
     RS-232C port number: 1 to 99.
     Handling sentence:   GGA, RMC, GSA, GSV, GLL, VTG, ZDA, DTM,
                          HDG, HDM, HDT, SMD.


2. Option setting (Option).

   The option setting form opens with "Option" -> "Option setting".

   * GPS receiver.
     It selects the GPS receiver and it sets parameter.

     GPS name.
       The GPS receiver which you use is selected.
       In case of the GPS receiver which is not to the list, inputting GPS receiver name 
       and other parameters, when it clicks "OK" button, it can add.
       Alias specification is possible, if it inputs with the form of <Alias>= <Real name> 
       and the "OK" button is clicked.
         Example) i.Trek M3=BT-339.
                  Selection of "i.Trek M3" uses the data of "BT-339".

       Type name of registered.
         Not Selected : The for not yet register type (no GPS command).
         508PC        : EMPEX PokeNavi 508PC.
         BT-338       : GlobalSat BT-338 (SiRFstarIII).
         BT-339       : GlobalSat BT-339 (SiRFstarIII). =BT-338
         BT-359       : GlobalSat BT-359 (SiRFstarIII).
         BT-Q1000     : Qstarz International BT-Q1000
         BU-353       : GlobalSat BU-353 (SiRFstarIII).
         CRUXII/BTGPS : EMTAC Bluetooth GPS (Trickle power, SBAS command it is attached).
         GPS-BT74R    : GPSInstantFix Technology GPS-BT74R (no GPS command).
         GM-38        : SAN JOSE NAVIGATION, INC. GM-38.
         GM-48-AT     : SAN JOSE NAVIGATION, INC. GM-48-AT.
         GPS65EZ      : EMPEX PokeNavi GPS65EZ (no GPS command).
         i-Blue       : TranSystem i-Blue (no GPS command).
         i-Blue737    : TranSystem i-Blue737.
         i-Blue747    : TranSystem i-Blue747.
         i-Blue747A+  : TranSystem i-Blue747A+.
         i.Trek M1    : Semsons i.Trek M1 (NEMERIX BT-15). =BT-15(NEMERIX)
         i.Trek M3    : Semsons i.Trek M3 (SiRFstarIII BT-339). =BT-338
         i.Trek M5    : Semsons i.Trek M5 (NEMERIX) (no GPS command).
         i.Trek S3    : Semsons i.Trek S3 (SiRFstarIII BU-353). =BU-353
         M-1000       : HOLUX Technology M-1000.
         M-241        : HOLUX Technology M-241.
         PCGPS        : IO-DATA PCGPS (no GPS command).
         SiRF(general): SiRF corporation make GPS general purpose
                        (Only selection of output sentence and cold & warm start).
         V-900        : Columbus V-900.
         VGPS-900     : VISIONTAC VGPS-900. =V-900
         WBT-200(6090 R2) : Wintec WBT-200 (Firmware Ver.3.31.6090 R2).
         WBT-200(6090 R6~): Wintec WBT-200 (Firmware Ver.3.31.6090 R6 or later).
         WBT-201      : Wintec WBT-201 (G-Rays2).
         WSG-1000     : Wintec WSG-1000.

     Start sentence.
       As for start sentence you use for the pause detection at the time of log playback.
       When start sentence is not included in the log, playback speed becomes abnormal.

     Time synchronization (Sync Adj).
       The number of compensation seconds for adjusting a time synchronous delay is 
       specified (0 to +-5.0 second).
       Inputs the lag time of time output of the GPS receiver at the second unit (The input 
       below a decimal point is also possible).
         Note) When the output timing of a GPS receiver does not synchronize with UTC time 
               and it does not output under a second to UTC, the correction for less than 
               +-0.5 seconds is impossible.
               Furthermore, since timing changes by the change in the number of output 
               sentences, or the number of the characters in a sentence, a precise 
               synchronization is not expectable.

     DEL button.
       Information of the GPS receiver which presently is selected everything is deleted 
       from the setting file (NMEA.INI).

     Exception.
       When select the "Not supported & not Private only" of "GPS Command/Report", the 
       sentence which excludes indication is appointed.
       It can utilize in order to make the indication of status and the like when 
       initializing easy to see.
       When multiple sentences are appointed divide with ",", there is no space with 
       describe.
         Ex.) $GPBOD,$GPRMB,$GPRTE,$PGRME,$PGRMM,$PGRMZ

     Max Sat.
       The maximum number of indicatory in GSV sentence indication satellites is appointed.
       In case of 12 satellites 3 sentences and in case of 16 satellites it displays 4 
       sentences.
       At the time of 12 satellites in case of 3 sentences and 16 satellites it indicates 
       4 sentences.
       When "Default" is selected, you follow the setting of "Max 16 satellites" 
       indications of option setting.
       Having done always in 16 satellite indicatory modes, in regard to operation there is
       no problem.

     SNR graph.
       The indicatory range and threshold level in the SNR bar graph it appoints.
       This is used only in order to make the graph of SNR easy to see.
       Threshold is indicated with the dotted line and uses in the standard of reception 
       possible level (does not indicate the value of 0).

   * Option.
     Other option items are set.

     Sky-plot by linear:   When check is removed, the cosine graduation is used for angle 
                           of elevation.
     Ignore Check-Sum:     When it checks, checksum error is ignored.
     Max 16 satelites:     Default of the maximum number of satellites with GSV sentence 
                           is designated as 16 satellites.
                           In case of not yet check it makes to 12 satellite 3 sentences.
                           Note) Individual setting every of GPS receiver takes precedence.
     ddmm.mmm format:      Latitude longitude of GPS output is indicated with type of 
                           original "Degree,Minute".
                           Resolution of latitude longitude output (the number of output 
                           below the decimal point of minute) you can verify.
     Automatic re-origin:  Starting point renewal is executed automatically when mean 
                           place above approximately 3m leaves from starting point
                           (Migration length in order not to have an influence on the 
                           calculation of 2drms, makes the 0.1m step).
     Hint display:         When check is removed, it stops doing hint indication.
                           When hint indication is troublesome, please remove check.
     UTC fluc.(RMC):       Warning value of UTC interval fluctuation between RMC sentence
                           (sec.).

   * Local time.
     The data in order to convert UTC to the local time is set.

     Time diff:  The time difference of UTC and the local time is set (in Japan 09:00:00).
     Short name: Abbreviation of the time zone is set.
     Auto:       When it checks, the setting of OS is acquired automatically.
                 An abbreviated name pickup and creates only a capital letter from the 
                 time zone name of OS (Only when a time zone name is returned with an 
                 English character).
                 It specially converts it into "JST" for "Tokyo Standard Time" or 
                 "���� (�W����)" the Time zone name.

   * Serial port.
     It sets the serial communication port.

     Port:    Number of the serial port which connects the GPS receiver is set.
     Baud:    Transmission speed of the serial port (baud rate) it sets.
     Log Out: When it checks, the data at the time of log playback can be output to also 
              the serial port(Verification dialogue is displayed in when starting the 
              playback).
              It can utilize in the test of the data logger etc., as a GPS simulator.
     Re-connect: When it checks, automatic re-connection of a serial port.
              A serial port is among open, and when a non-signal state continues, 
              re-opening of a serial port is performed.
              A connection cycle follows a setup of "ReOpen" of "GPS Command/Report"
              (Min: 5Sec).
              It is useful to recovery of the broken link of Bluetooth.
     Scan:    The serial port where GPS is connected is searched.
              After appointing transmission speed, it clicks "Scan" button.
              When the "Abort" button is clicked, search is discontinued.
              When the "Retry" button is clicked, search is reexecuted.
              When GPS is not found, please try enlarging waiting "Wait" (1.5 to 5 
              recommended).
              Note1) When specification "Baud" differs from the transmission rate of GPS 
                     largely, there are times when GPS cannot be detected.
              Note2) It can detect virtual serial port such as BlueTooth adapter regardless
                     of transmission rate.

   * Printing and copy.
     Popup menu - it indicates with the right click of the mouse, can copy to printing and 
     the clipboard of form image.


3.  Printing and copy (Main Form)

   "File" -> "Print" the Form picture the hard copy is done in the printer.
    It is copied to also the clipboard. The paper of A4 size is necessary.

   "File" -> "Copy" image of Form is copied in the clipboard.


4. Record of data/playback.

   * Playback indication of GPS data.
     It replays the data file which was saved in the record and it displays data.

     When file name is appointed with "File" -> "Start Replay", it becomes log playback 
     mode and the track bar and the operation button are appear.
     It ends log playback mode in "File" -> "Stop Replay".

     When ">" the button is clicked, playback is started.
     When starting the playback output interval of the original data it plays back 
     unrelated always at 1 second interval, but refresh rate at each time the ">" button 
     is clicked becomes quick.
     Point of playback is indicated with the track bar, When the track bar the drug is 
     done with the mouse, the playback point can be modified.

     When "+" button is clicked, just 1 data replay in forward direction, when "-" the 
     button is clicked, just 1 data plays back in opposite direction (step playback).
     When "||" button is clicked, playback is pause.

     When "Log Out" check box of the "Serial port" section of option is checked, when 
     starting the verification dialogue whether or not it outputs the log playback data 
     to also the serial port of, is indicated.

     The drug & drop doing the log file in main form, it starts log playback.
     However, during of log recording and while playing back are ignored.

     Form size can be minimized if it clicks on "maximize/minimize" icon.
     If it clicks once again, it will return to the original size(Only when Log playback
     data is outputted to a serial port).

   * Record of GPS reception data.
     The raw data from GPS almost that way to the text file it records retains.

     Appointing file name with "File" -> "Start Recording" it starts record.
     When extension name is abbreviated, ".nmea" is added.
     Record is stopped by "File" -> "Stop Recording" and a file is closed.

     Note) When extension name of default is modified, Setting file "NMEA.INI" the part 
           of "NmeaExt=.nmea" of the [Option] section is modified.

5. GPS Command/Report.

   The GPS command/report indicatory window opens in the "Tool" -> "GPS Command/Report".
   The drug doing the window corner, it can expand and reduce the size of the window.

   * GPS command transmission (GPS command).
     Optional command is send to the GPS receiver.
     Because it has automatic operation addition of checksum and display function, 
     checksum calculation is unnecessary.

     Inputting GPS command, when it clicks "Send", it transmits the command character 
     string to the GPS receiver, that command is registered to the drop down list.
     It can record every GPS receiver to 100 commands.

     When "Delete" button is clicked, the GPS command which it is selective is deleted 
     from record in "NMEA.INI".

     To include control character to GPS command, the escape sign "\" continuing, 
     hexadecimal character string 1 or 2 columns it appoints (0-9, A-F, a-f).
     "\" as for itself "\\" , "|" as for itself "\|", ";" as for itself "\;" The way you 
     describe.
     When the space is included "\ " or "\20" you describe.

       Ex.) Input character string and output (hexadecimal notation) correspondence.
            a\12b -> 61 12 62   x\ay -> 78 0A 79   x\yz -> 78 79 7A
            a\012 -> 61 01 32   a\\b -> 61 5C 62   a\|b -> 61 7C 62

     If the beginning of command A0 A2 then regard as SiRF binary command, when checksum is 
     abbreviated, checksum and End-sequence(B0 B3) are added automatically.
     If the beginning of command B5 62 then regard as UBX binary command, when checksum is 
     abbreviated, checksum are added automatically.

     Concerning forwarding and CheckSum addition control of multiple commands later 
     description "11. About the setting file" it is reference.

   * Option.
     Fix time: It displays the elapsed time which fixs after sending out a GPS command.
               If a time display is clicked, a display will disappear and a check box will 
               appear.
     Chk-Sum:  When checksum is not included in command, checksum is added.
               If the end of a command character sequence is "*", CheckSum is not added, 
               but "*" is deleted and sent out.
     Cr:       The Carriage-return code is added to GPS command (usually checks).
     Lf:       The Line-feed code is added to GPS command (usually checks).

   * Indication of non support sentence and selective sentence.
     Only the sentence which is not supported, only the sentence which is selected, 
     selecting all sentences, it can indicate.

     Indicatory contents are selected with combo box of the left top.
       Not supported only:     Only the sentence which is not supported with the NMEA 
                               monitor is indicated.
       Not supported & 
       not private only :      Except for the "Exception" sentence specified as the option,
                               it displays from the above-mentioned display.
                               (Indication of status when initializing etc., can be made 
                                easy to see).
       Display all sentences:  All reception data are indicated.

       Only the corresponding sentence is displayed except the above.

     When "Hex" check box is checked, being to indicate reception sentence hexadecimally, 
     verification of the binary code of non indication can do with text mode (the data of 
     indicatory end does not change).
     When "Time" check box is checked, adding UTC time to the forefront of reception 
     sentence, it indicates.
     As for the first 1 character "N" of line does not support, "?" unknown sentence is 
     displayed.

     When indication exceeds 30KBytes, it keeps being deleted from old line.

     A mouse cursor is put on a boundary with an error sentence display part, and if cursor 
     form drags in the position which changed to the up-and-down arrow, the height of a 
     display domain can be adjusted.

       Note) The time of the head of a line is generated and added from GPS data.
             When SiRF binary is received, "SiRF-Bin" it indicates in place of time.
             When UBX binary is received, "UBX-Bin" it indicates in place of time.


   * Error sentence.
     Only the sentence which has error is indicated.
     In addition the reception data is indicated in during playback log transmitting.

     When "S" is attached to the head of a line, the sentence of a checksum error is 
     expressed.
     When "R" is attached to the head of a line, the RS-232C receiving character sequence 
     under playback log transmission is expressed.

     When "Hex" check box is checked, reception sentence is indicated hexadecimally.
     When "Time" check box is checked, adding UTC time to the forefront of reception 
     sentence, it indicates.

     UTC time and this time of RMC sentence immediately before are compared.
     If above the value which difference of the last time specifies with option as 
     description below alert warning is displayed(is above differential time 60 second, 
     it does not output).
     A warning output is not performed if specification of "UTC fluc.(RMC)" of an option is 
     zero.
       * UTC step changed :   1.00 to   2.00Sec.  UTC(RMC)=12:34:56.789

     When indication exceeds 30Kbytes, it keeps being deleted from old line.

       Note) The time of the head of a line is generated and added from GPS data.

   * RS-232C.
     A status display and control of RS-232C are performed.

     DTR, RTS: When it checks, the signal line which corresponds is made active.
               Immediately after of the RS-232C opening is always active.

     DSR, CTS,
     CD, RING: When being active, it indicates with red (in every 1 second renewal).

     F.Er:     Framing error.
     P.Er:     Parity error.
     O.Er:     Buffer overrun Error.
     NoSIG:    Serial port input more signalless 2 to 3 seconds.

     Function of push button.
       Open:   The RS-232C port is opened.
       Close:  The RS-232C port is closed.
       ReOpen: Closing the RS-232C port, it re-opens after the designated time.

   * Printing and copy.
     Popup menu - it indicates with the right click of the mouse, can copy to printing and 
     the clipboard of Form image.
     Also printing and the copy of the corresponding text can do with the right click on 
     combo box and the memo component.


6. Indication of Track and averaging value(Average display).

   The mean value of Latitude Longitude, Altitude and Track can be indicated in "Tool" -> 
   "Average display".

   * Indication of mean value.
     If a "Start" button is clicked after configurating the upper limit of HDOP to 
     averaging, averagingn will be started, and averaging will be stopped if a "Stop" 
     button is clicked (When the specification value of HDOP is blank, it averaging without 
     restriction by HDOP).
     The data which is not Fix is disregarded and is not used for averaging.
     When the GSA sentence is outputted, only the data at the time of 3-dimensional 
     positioning is used for an average altitude.
     "The number of times of an average of latitude longitude" and "the  number of times 
     of an average of altitude" are respectively displayed on the column of "Count".
     2drms display the theoretical value of the radius of the circle which is horizontal 
     position accuracy and is supposed that 95% of all positioning points are included 
     (It is proper, but if determination it does not do in position fixing, there is no 
     meaning).
     Because it calculates elapsed time from the data of GPS, even in at the time of log 
     playback it can indicate correctly.
     When "Reset" button is clicked, value is initialized.

     Note) Please observe the measurement of 2drms for about 12-24 hours in open sky.
           Measurable quantity fluctuates with influence of measurement region and condition 
           of the satellite etc.

   * Indication of Track.
     With "Track" the locus which designates the position when starting averaging as 
     standard is displayed with the dot.
     When "Average" tab is clicked, change of mean value is indicated with Track.
     It cannot indicate with polar nearby high latitude area correctly.
     To be offered by the one for drift verification of GPS output mainly, as for the 
     indicatory range the +-0.5 to +-200 m.
     When "Origin" button is clicked, present mean value (within +-5cm) setting to the 
     start position, it continues levelling (For storage capacity conservation logarithm 
     compressing, because it retains the point, resolution has become non-linear.
     Because of this at each time "Origin" is executed, being proportionate to migration 
     length, Track becomes deformed).
     When "Rreset" button is clicked, also Track is cleared.

     When the mouse the right is clicked, popup menu - is indicated.
       Clear Track:       Clearing present Track, only new Track indicates.
       Track by 1 pixel:  It indicates Track with 1 pixel.
       Track by 4 pixels: It indicates Track with 4 pixels.
       Print Form :       Image of Form is printed in the printer.
                          It is copied to also the clipboard.
       Copy Form:         Image of Form is copied in the clipboard.

     Distance: Resolution.
       0.5m:0.04m,  1m: 0.05m,  2m:0.08m,  5m:0.16m,  10m:0.3m,  20m:0.56m,  50m:1.4m, 
       100m:2.7m, 200m:5.4m.

   Restriction item.
     1) When GGA sentence is not output, it cannot averaging MSL altitude, 
        (In order to substitute a RMC sentence).
        In this case HDOP of GSA sentence is used, but when either GSA sentence is not 
        output, ignoring the appointment of HDOP, it averaging.
     2) When neither of GGA and RMC is output, it cannot indicate mean value and Track.


7. Time correction of personal computer (Clock synchronization).

   When the GPS receiver Fix and RMC or ZDA sentence is output, The calendar timer of the 
   personal computer is adjust with "Tool" -> "Clock synchronization" making use of the 
   GPS time data.
   When the correction quantity exceeds 30 minutes, verification dialogue is indicated.
   With Windows XP and the like it is necessary to have logged on with the account of the 
   administrator.

    Note 1) The time lag of the UTC output of a GPS receiver is set as "Sync Adj" of the 
            "GPS receiver" of an option, and the time of PC can be revise.
    Note 2) When the cold start or long time it is not used, depending upon the GPS 
            receiver, immediately after the GPS fix, there are times when it cannot revise 
            leap second just.
            In this case after 13 minute after the Fix or more elapsing, please perform.
    Note 3) When RMC is not output, for deciding the determination state, GGA or GLL 
            sentence is necessary other than ZDA.
    Note 4) With "Windows Vista" Administrator is necessary in correction of time.
            When "Run this program as an administrator" check is inserted with the 
            executable file or the property of shortcut, it reaches the point where 
            being promoted dialogue to Administrator is indicated in when starting.


8. Indication of differential time of the GPS UTC and PC-time and sentence reception time.

   Form is opened in "Tool" -> "Time lag of GPS to PC", differential time of the UTC time 
   of GPS and personal computer time (GPS time - PC time), reception time of sentence is 
   indicated in each sentence in real time.
   Please use after synchronizing the clock of a personal computer with a time server etc.,
   (It is desirable that it can synchronize in the accuracy for less than 0.1 second).
   "Sakura Watch network time client" by Mr. UNO Shintaro is recommended if it uses it in a 
   Japanese mode.
     inflation! - uno's homepage: http://www.venus.dti.ne.jp/~uno/
     File: http://www.venus.dti.ne.jp/~uno/software/skrw/skrw021.lzh

   Since it has the influence of the number of serial data bytes, internal processing 
   delay, etc., Under a second is regarding it as a rough standard.
   Since timing changes also in the existence of a GSA, GSV sentence, when the sending-out 
   sequence of a NMEA sentence can be specified like i.Trek Bluetooth GPS, it will be good 
   to specify GSA and GSV to be an end.

   When the "Statistics" check box is checked, the maximum value, minimum value and the mean 
   value of the time difference are displayed.
   The display is discontinued when the check is removed and statistics are clear.

   Popup menu - it indicates with the right click of the mouse, can copy to printing and 
   the clipboard of Form image.

      Note 1) When there is a differential time above +-12 hours, differential time cannot 
              be indicated correctly.
      Note 2) If "Statistics" check box is off and Form is closed when unnecessary, 
              Unnecessary calculation processing is not performed.
      Note 3) Usually, resolution of the calendar timer with the Windows machine is 
              approximately 15.6mS, but there are times when occurs the processing delay 
              of several dozen mS or more with such as task waiting.


9. Indication of reception data.

   * Data display of each sentence.

     Whenever it receives data, a data display is updated, and the title background of 
     corresponding sentence blinks.
     Error status is indicated in the right side of sentence title.
       E: Checksum error,  L: The number of items excessive, N: There is no checksum.

     DTM, HDG, HDM, HDT, SMD sentence becomes change indication (simultaneous indication is
     not possible).
     When the letter of "D,G,M,T,S" above the left is clicked with the mouse, indicatory 
     contents are changed.
       DTM: $GPDTM, HDG: $HCHDG,  HDM: $HCHDM, HDT: $HCHDT, SMD: $IISMD
     When the character of "C" above the left is clicked with the mouse, the display window
     of the CHN sentence is opened.
        CHN: $PMTKCHN

     Correspondence of sentence sign and characters on screen line.

       GGA.
         GPS Quality Indication = 0: Invalid           1: SPS fix
                                  2: DGPS fix          3: PPS fix
                                  4: RTK fix           5: FloatK fix
                                  6: Estimated         7: MANUAL input
                                  8: Simulator

       GLL, RMC.
         Status = A: Valid       V: Void

       VTG.
         True Course     = numerical value is blank, sign "T" is not indicated.
         Magnetic Course = numerical value is blank, sign "M" is not indicated.

       GSA.
         2D/3D mode = A: AUTO        M: MANUAL
         Mode       = 1: Not fix     2: 2D fix    3: 3D fix

      The mode of VTG, GLL, RMC.
         A: Autonomous     D: Differential   E: Estimated
         M: MANUAL input   S: Simulator      N: Not valid

      Each sentence commonness.
        When numerical value such as altitude and speed is blank, unit symbol "M, K, N" 
        and so on it does not indicate.

    Note) Depending on a GPS receiver, the altitude from WGS-84 ellipse to a receiver is 
          output to the MSL altitude of a GGA sentence (Especially in the case of the 
          receiver which does not display geoid quantity, it is careful.).
          In this case geoid height subtraction those which are done become altitude from 
          indicated value.

          Moreover, although an MSL altitude is outputted in TOKYO datum, keep in mind that 
          there is also a GPS receiver which outputs the altitude from WGS-84 ellipse to a 
          receiver in WGS-84 datum.

          Concerning the geoid height of Japan the Web page of national geographical 
          institute "Shape of the earth is measured", Please refer to 
            http://vldb.gsi.go.jp/sokuchi/shape.html
          Ref.) The geoid of Tokyo stations height has become approximately 36.6 m.

   * Position indication of satellite (Sky plot).

     GSV sentence is necessary in the indication of Sky plot.
     A GSA sentence is required to indicate the satellite in use by classification by color.

     Display position.
       As for azimuth 0 degree as for "N", and 90 degrees as for "E", and 180 degrees "S", 
       and 270 degrees correspond to "W".
       It converts angle of elevation to the distance of radial, the center 90 degrees, 
       circle outside corresponds to 0 degrees.
       Circle inside is angle of elevation 60 degree and 30 degrees.

     Indicatory mark.
       Satellite number indicatory mode.
         A satellite number is displayed. The used satellite in GSA is expressed as the 
         background of  Red(fixed)/Yellow(non fixed).
       SNR indicatory mode.
         It indicates SNR, Red(fixed)/Yellow(non fixed) indicates the use satellite with 
         GSA with the background.
         SNR with indicates the satellite of blank "+".

     Indication of direction.
       In outside circle travelling direction is indicated with the dot of blue.

   * The indication of SNR.

     SNR each of satellite is indicated in the bar graph.
     The bar of a satellite in use is painted out black(depending on GSA sentence).
     Display order follows a GSV sentence.
     Numerical value expresses a satellite number (PRN).


10. Change of a display language.

    With "Language" -> "Japanese" Japanese indication, with "Language" -> "English" it 
    becomes English indication mode.
    Display font can be specified by "Language" -> "Font".
    Keep in mind not settled within the display limit depending on the kind or size of a 
    font.

    As for Japanese font name of default "MS Gothic", as for size it has become "9".
    As for English font name of default as for "Courier New" and size it has become "9".
    It can appoint also the attribute of Color and the Bold type etc., but the fact that 
    it save in the setting file is only font name, character set and font size.


11. About the setting file.

    Setting is retained in Text file "NMEA.INI".
    When the folder with the configuration file is read-only, it copies onto folder 
    %APPDATA%\NMEA\ and it uses it.
    %APPDATA% is a folder displayed to input by the DOS prompt as "echo %APPDATA%" <Enter>.

    * GpsData section.

      The number of the maximum satellites, name of a GPS receiver, range of SNR graph, 
      threshold value, start sentence, GSA sentence (12 or 16), time synchronous number of 
      adjustment seconds, and an exception sentence are specified.

      Range specification is used in order to make the graph of SNR legible, and it is 
      specified in order of a maximum and a minimum according to a GPS receiver.
      A threshold value is displayed by the dotted line on SNR graph (it does not display 
      if 0).
      As for start sentence you use for the pause detection at the time of log playback 
      (default it makes GGA).
      When the maximum number of satellites of GSA sentence is abbreviated, follow the 
      setting "Maximum 16 satellites" of option.
      When the number of adjustment of time synchronization seconds is blank, it does not 
      revise.
      The comma "," with dividing, plural it can appoint exception sentence.

      When would like to change the indicatory order of the drop down list, please correct 
      with text editor etc.,.

      Example)
        [GpsData]
        Not Selected=99,0,0,GGA,16
        GM-48-AT=60,20,30,RMC,16,0.36,
        CRUXII/BTGPS=60,13,28,,12,0.9
        508PC=60,0,15,,12,1.4
        PCGPS=60,15,30,,12
        GM-38=70,25,35,,12,0.5
        GPS65EZ=20,0,3,,12,1.2,$PKODA,$PKODG
        SiRF(general)=60,0,0,,12

   * GpsCmd XXXX section.

     When GPS command sending is executed, is recorded automatically (GPS type name enters 
     into XXXX part).
     It can record GPS command every GPS receiver up to 100.
     When would like to change the indicatory order of the drop down list, please correct 
     with text editor etc.,.
     Although a key may be suitable if it does not overlap, it is rewritten by the form 
     of "Cmd.." at the time of preservation of a file.

     Plural commands are sending, "|" with it divides (approximately 1 seconds pause 
     between command).
     When pause time between command is not enough, "|" it adds (per 1 approximately 1 
     second increase).
     Baud rate after the GPS command forwarding can be specified to the comment part
     ( \B9600\ The way numerical value is surrounded with "\B" and "\" ).
     After of the semicolon is ignored regarding comment.
     If end in the command character string "*" it does not add CheckSum and "*" deletes 
     and sending (Option setting having become "Chk-Sum" it is ignored).
     In case of the binary command of SiRF and UBX CheckSum (2 bytes) it can add.
     When the string surrounded with "\\" and "\\" in a comment part is described, 
     the string is indicated, and execution confirmation is performed.

    Example)
     [GpsCmd BT-338]
     Cmd0=$PSRF104,0,0,0,96000,1,1,12,1 ;Hot start
     Cmd1=$PSRF104,0,0,0,96000,1,1,12,2 ;Warm start
     Cmd2=$PSRF104,0,0,0,96000,1,1,12,4 ;Cold start
     Cmd3=$PSRF104,0,0,0,96000,1,1,12,8 ;Cold start(Resets to factory defaults)
     Cmd4=$PSRF106,21   ;WGS84 datum
     Cmd5=$PSRF106,178  ;Tokyo-Mean datum
     Cmd6=$PSRF106,179  ;Tokyo datum
     Cmd7=$PSRF106,180  ;Tokyo-Korea datum
     Cmd8=$PSRF106,181  ;Tokyo-Okinawa datum
     Cmd9=$PSRF103,00,00,01,01  ;GGA 1 second period
     Cmd10=$PSRF103,00,00,00,01  ;GGA off
     Cmd11=$PSRF103,01,00,01,01  ;GLL 1 second period
     Cmd12=$PSRF103,01,00,00,01  ;GLL off
     Cmd13=$PSRF103,02,00,01,01  ;GSA 1 second period
     Cmd14=$PSRF103,02,00,03,01  ;GSA 3 second period
     Cmd15=$PSRF103,02,00,00,01  ;GSA off
     Cmd16=$PSRF103,03,00,01,01  ;GSV 1 second period
     Cmd17=$PSRF103,03,00,03,01  ;GSV 3 second period
     Cmd18=$PSRF103,03,00,00,01  ;GSV off
     Cmd19=$PSRF103,04,00,01,01  ;RMC 1 second period
     Cmd20=$PSRF103,04,00,00,01  ;RMC off
     Cmd21=$PSRF103,05,00,01,01  ;VTG 1 second period
     Cmd22=$PSRF103,05,00,00,01  ;VTG off
     Cmd23=$PSRF103,00,00,00,01|$PSRF103,01,00,00,01|$PSRF103,02,00,00,01|$PSRF103,03,00,00,01|$PSRF103,04,00,01,01|$PSRF103,05,00,00,01 ;Only RMC interval of 1 second.
     Cmd24=$PSRF103,00,00,01,01|$PSRF103,01,00,01,01|$PSRF103,02,00,01,01|$PSRF103,03,00,05,01|$PSRF103,04,00,01,01|$PSRF103,05,00,01,01 ;Outputs all sentences.
     Cmd25=$PSRF150,0,1000,1000,0 ;Power Save Off
     Cmd26=$PSRF150,0,300,1000,1  ;Power Save On
     Cmd27=$PSRF151,00 ;WAAS/EGNOS Off
     Cmd28=$PSRF151,01 ;WAAS/EGNOS On
     Cmd29=$PSRF109,129 ;SBAS Channel PRN129 #42(MTSAT-1)
     Cmd30=$PSRF109,137 ;SBAS Channel PRN137 #50(MTSAT-2)
     Cmd31=$PSRF109,135 ;SBAS Channel PRN135 #48(WAAS)
     Cmd32=$PSRF109,138 ;SBAS Channel PRN138 #51(WAAS)
     Cmd33=$PSRF109,120 ;SBAS Channel PRN120 #33(EGNOS)
     Cmd34=$PSRF109,124 ;SBAS Channel PRN124 #37(EGNOS)
     Cmd35=$PSRF109,126 ;SBAS Channel PRN126 #39(EGNOS)
     Cmd36=$PSRF109,131 ;SBAS Channel PRN131 #44(EGNOS)
     Cmd37=\A0\A2\0\18\81\2\1\1\0\1\5\1\5\1\1\1\0\1\0\1\0\1\0\1\0\1\96\00\01\2F\B0\B3 ;Binary to NMEA mode(38,400bps)  \B38400\
     Cmd38=$PSRF100,0,38400,8,1,0  ;NMEA to SiRF binary(38,400bps)  \B38400\
 
   *Option section.

    CaptureDelay : Appoints the waiting at the time of Form capture (default is 8).
                   When the sub menu remains in the picture, please enlarge value (the 
                   50mS unit).

    IgnoreSpace :  After space in the NMEA sentence is deleted, it analyzes it for "1".
                   It analyzes it as it is for "0".

    ReadExt :      The extension name of the NMEA log file for reading is specified.
                     Default value:  .nme.nmea.nma.log.txt

   Concerning other section please refer to the comment of the "NMEA.INI" file.


12. Command line option.

    A setting file is specified to be a command line, It can use another setting file in 
    place of "NMEA.INI" of default.
    As for extension name of setting file it must be ".INI".
    In addition also it is possible to appoint the Log file.
    Extension name of the Log file makes 4 types of ".nmea", ".nme", ".Log", ".txt".

    When a drive name and a path are omitted, It shall be in the same folder as NMEA.EXE.
    When the setting file does not exist, it is make up anew.

      Example) 
        NMEA Other.ini            "Other.ini" in same folder with executable file is used.
        NMEA C:\GPS.ini           "GPS.ini" of C: drive route is used.
        NMEA Other.ini Test.Log   Setting file "Other.ini" to read, and
                                  "Test.Log" is played back.
        NMEA Test.nme             Log file "Test.nme" is played back.

      When the GPS receiver 2 or more is connected to 1 PC simultaneously, it is convenient 
      if you create the shortcut of NMEA.EXE (The created shortcut is right-clicked, a 
      property is chosen and a setting file name is added to the end of a link place).

    Note) Setting file and Log file the drug & drop doing in the icon of NMEA.EXE, it is 
          possible also to start.
          However, during of log recording and while playing back are ignored.
          Setting file and the Log file only each 1 file are effective (When plural is 
          appointed, the first file is used).

    Automatic record start of NMEA data.

      When "/W" is added to the log file name of the command line, the record is started 
      automatically by the file name.
      When the file name is omitted, beginning date (yyyy-mm-dd_hh-mm-ss) is made a file name.
      When the blank is included in the file name and path, it encloses with double quotes.
      If the log file has already existed, it adds it to the file.

      Ex) NMEA Test/W
            Data is recorded in "Test.nmea" of the same to execution file folder.

          NMEA /W
            It records by the file name "<time of the date when starting>.nmea".

    GPS command sending when starting: /B
      When starting, it sends it automatically when the command number in the configuration 
      file is specified.
      Ex) Cmd1/B

    GPS command sending when ending: /E
      When ending, it sends it automatically when the command number in the configuration 
      file is specified.
      Ex) Cmd10/E

    Automatic termination: /Q
      When the time specified by "<Days>/Q" passes, it ends automatically.
      Ex) NMEA 0.125/Q    It will end in three hours automatically.

    Minimization: /S
       After it start-up, the form is minimized.

    Combination example.
      NMEA test.ini Cmd1/B /Q
        Configuration file "test.ini" is used and Command "Cmd1" of GPS is sent and it ends 
        immediately


13. Troubleshooting.

   * The reception data is not indicated.

     1) Port number of serial port mismatch.
        "Port" of a serial port is set as the port which connected the GPS receiver as an 
        "Option" -> "Option setting", and "OK" is clicked.

        When the serial port non inputs, "NoSIG "is indicated in the error status of 
        RS-232C with the "Tool" -> "GPS Command/Report".

     2) Transmission speed of serial port mismatch.
        In combination with "Baud" of the serial port to the speed of the GPS receiver 
        with "Option" -> "Option setting", clicks "OK" (NMEA standard is 4800bps).
        When the connected port and baud rate are unclear, when "Scan" button is clicked,
        auto search the serial port and report the result.

     3) Output mode of the GPS receiver has become SiRF binary mode.
        When "Tool" -> "GPS Command/Report" -> "Not supported only", "SiRF-Bin" is 
        indicated in the report forefront.
        The below-mentioned GPS command please transmit.
          \A0\A2\0\18\81\2\1\1\0\1\2\1\2\1\1\1\0\1\0\1\0\1\0\1\0\1\12\C0\1\65\B0\B3 ;\B4800\
          (transmission speed of the GPS receiver is reset in 4800bps).

   * Average of mean value is not started immediately.

     When a HDOP value is specified, it stands by until HDOP of receiving data becomes 
     below this value.

   * We would like to set the port and transmission speed outside the range.

     It can set up, if hardware and the driver correspond and a port number and 
     transmission speed will be inputted by manual.

   * GPS command and option setting are not retained.

     Setting file (with default NMEA.INI) has become write protect, setup cannot be saved.

   * Power saving function of the SiRF make GPS receiver is abnormal.

     It seems that the shortest time of power-on is prescribed by the power supply 
     injection cycle (The power-saving function is not mounted depending on the model).

      1 to 2 second period: Above power-on 200mS.
      3 to 6 second period: Above power-on 300mS.
      7 to 8 second period: Above power-on 400mS.

   * The sub menu remains from the capture picture and printing of form.

     Setting file please try enlarging the value of "CaptureDelay" of the "Option" section 
     of "NMEA.INI".
     As for default 8 (waiting of 50mS unit).

   * It cannot print form image.

     It prints, after carrying out the capture of the form image to a clip board.
     For this reason, when other applications are using the clip board, printing may go 
     wrong depending on timing.

   * Japanese character garbled.

     It appoints the european font, or "character set" of font setting does not become 
     "Japanese".

   * Japanese character garbled partly in Windows XP English edition.

     When Japanese character such as title bar of form, push button, radio button, 
     check box etc., is garbled. below-mentioned configuration is done.

     "Japanese" to configurate "Languabe for non-Unicode programs" in "Advanced" page of 
     "Regional and Language Options" of "Control Panel" of Windows to, after clicking 
     "OK", it restarts.

   * Abbreviated name of a local time is not displayed correctly.

     In Windows other than the English version, please turn OFF the "Short name" of the 
     "Local time" of an option setting "Auto", and input a "Short name" manually.

   * Time synchronizing fails.

     Comparing the difference of UTC and the PC time which are included in RMC immediately 
     before and the difference of the latest RMC reception time, when it is within 0.1 
     seconds only, it runs time synchronization.
     Therefore when RMC 1 second cycle, GSA, GSV is 2 second cycle, when RMC is forwarded 
     hugely after GSA, GSV because the timing of RMC changes in every time, there are times 
     when it cannot do time synchronization.
     In this case, it is solvable by making GSA, GSA into 3 seconds or more, or making it 
     the cycle of 1 second.

     With "Windows Vista" Administrator is necessary in correction of Time.
     When "Run this program as an administrator" check with the executable file or the 
     property of shortcut, it reaches the point where being promoted dialogue to 
     Administrator is indicated in when starting.

   * "Cannot access registry!!" Can be indicated and cannot detect the serial port of mounted.

     Because registry cannot read with "Windows Vista", it cannot detect the serial port.
     When "Compatibility mode" is set to "Windows XP (Service Pack2)" with the executable 
     file or the property of shortcut, the reading of registry becomes possible.

   * Command via Bluetooth is ignored.
     As for i-Blue747 and BT-Q1000, the command via Bluetooth is ignored.
     The command is ignored when feeding power with the USB cable even when "Resistor Hack" 
     is applied.


14. PRN of SBAS and correspondence of GSV sentence satellite number.

  For SiRF Star and MTK (GSV SV# = PRN - 87)

          SV     PRN  GSV SV#   Long.
      MSAS
        MTSAT-1  129 -> 42      140�E
        MTSAT-2  137 -> 50      145�E

      WAAS
        Galaxy   135 -> 48      133�W
        Anik     138 -> 51      107�W
       (AOR-W    122 -> 35      142�W  Phased out)
       (POR      134 -> 47      178�E  Phased out)

      EGNOS
        AOR-E    120 -> 33      15.5�E
        Artemis  124 -> 37      21.5�E
        IOR-W    126 -> 39      25�E
        IOR      131 -> 44      64�E

  In case of NEMERIX, PRN number of 3 digit is output to GSV sentence.


15. Used compiler and component.

    In compiler used
      Delphi 2007 Professional(Delphi for Win32)   Borland Software Corp.

    In addition free component used
      CommX Ver1.06 X(KYY06770) person work. RS232C communication component COMMX106.LZH
      In the writer who the very useful component was offered we appreciate.


Release note.

 * This application is the free software.
 * It does not prohibit redistribution, but *.TXT and NMEA.EXE and *.INI including the 
   set of distribution.
 * GPS model and a command may be added to the setting file *.INI in the case of 
   re-distribution, change of other files is forbidden.
 * The author takes no responsibility to any losses and obstacles which were produced by 
   use or distribution of this application.


Version history.

Ver1.64 Jul. 2011
  1. The bug to which the progress bar of Windows 7 was not displayed was corrected.

Ver1.63 Jul. 2011
  1. The non-Fix status was displayed in the taskbar button of Windows 7.
     When non-Fix it displays by "Indeterminate" ( Progress a bar flickers ).

Ver1.62 Jul. 2011
  1. Kilo was corrected to the lower-case.

Ver1.61 Sep. 2010
   1. "/S" command line option was added (After it had start-up, the form is minimized).
   2. The log save folder of "/W" option was able to be specified with "WriteDir" of 
      the [Option] section of "NMEA.ini" (It is updated in "File" -> "Start Recording" operation).

Ver1.60 Oct. 2009
   1. To the extension name of the log file ".nma" was added (The change was enabled by the
      configuration file).

Ver1.59 Oct. 2009
   1. The command line option that started an automatic record of the log was added.
   2. The command line option that sent an any GPS command when starting and ending was added.
   3. The command line option that ended automatically was added.

Ver1.58 Jan. 2009
   1. Option to disregard Space(0x20) in the NMEA sentence was added to the configuration 
      file.
   2. Autocomplete of ComboBox was abolished.

Ver1.57 Dec. 2008
   1. The display of the $PMTKCHN sentence of the MTK chipset was supported.
   2. The output command of the $PMTLCHN sentence was added to the configuration file.

Ver1.56 Jun. 2008
   1. Prolonged the reversing display time for sentence label.
      It becomes easy to see the reception of the sentence even when a virtual port of 
      USB connection etc. is used.
   2. Dialog box was displayed at each form center.
   3. Icon was changed.
   4. Add a command of Wintec WSG-1000.

Ver1.55 May. 2008
   1. Corresponded to the display of the $IISMD sentence of Wintec WSG-1000.
   2. The run time theme of the compiler was invalidated.
      The serial port installed even when Windows XP compatibility mode is not set with 
      Windows Vista can be detected (A port not active is included).

Ver1.54 Feb. 2008
   1. The drag & drop to the main form of the configuration file was made effective.
   2. The number of characters of Memo components of the "GPS Command/report" form was 
      limited by the number of characters (not number of lines).

Ver1.53 Feb. 2008
   1. Mean value indication of South latitude and the West longitude was corrected
      (the minus sign was indicated in excess).

Ver1.52 Jan. 2008
   1. Measures when the configuration file was in a read-only folder were added.

Ver1.51 Sep. 2007
   1. The defect when unplugged a USB cable during communication, was reduced.
   2. In addition correction of detail.

Ver1.50 May. 2007
   1. The waiting time of the serial port search can have been specified. (default three 
      seconds/port)
   2. The "Retry" button of the serial port search was added.
   3. The thread processing when the port closing was corrected.

Ver1.49 Apr. 2007
   1. The compiler was changed into Delphi 2007 (Delphi for Win32).
   2. An end of line supported a sentence only for a Line-Feed (for logging modes of WBT-201).
   3. Made sure that execution confirmation can be designated by comment part of the 
      GPS command (The character string surrounded with "\\" and "\\" was indicated).
   4. When being not fixed, a background of a taskbar icon is indicated by yellow.

Ver1.48 Feb. 2007
   1. The date processing of a ZDA sentence was corrected.
   2. The date separator of RMC and ZDA sentence was made to follow a locale.
   3. The standard locale was changed into the U.S. from Japan.

Ver1.47 Feb. 2007
   1. The date format of RMC and ZDA sentence corrected having not followed OS Locale.

Ver1.46 Jan. 2007
   1. When the UTC date of a RMC was incorrect, it was made to perform a warning display.
   2. The bar graph of a signal level was displayed by XOR.
   3. Locales other than Japanese and English also operate normally.

Ver1.45 Nov. 2006
   1. At the time of sentence discontinuance the fact that minimum of the time difference of 
      PC becomes blank was prevented (Locking client size).
   2. Tried to adjust the size of each form automatically.
   3. When the reading of registry is not possible, it tried to scan serial port COM1 to 20.

Ver1.44 Nov. 2006
  1. At the time of the first run if OS Japanese mode it tried to set language mode to Japanese.
  2. HDG, HDM, HDT sentence was made indication possible.
  3. Handling to English monospaced font "Courier New", the display area has been expanded.
  4. The calculation method of 2drms was changed, and 2drms in the altitude was displayed.

Ver1.43 Aug. 2006
  1. It made the "Sky plot" and "SNR bar graph" to follow the font in the option setting.
  2. The bar graph of non fix was displayed in yellow.
  3. The search range of a serial port was extended by 99.
  4. In case of English mode the degree sign of latitude longitude " � " it indicates.
  5. In Origin indication of mean value font setting was made effective.
  6. Default extension name of log file. It modified in ".nmea".

Ver1.42 Jun. 2006
  1. It was corrected that the use satellite (red display) in the sky map was displayed 
     by mistake.
  2. The position where default was displayed was changed to the center of the display.

Ver1.41 Apr. 2006
  1. The alias function of a GPS receiver name was added and sharing of GPS data was 
     enabled.
     Sharing of the same data was attained from the OEM model and the original model.
  2. The cycle of automatic re-connection of RS-232C was made to follow specification 
     of "ReOpen" of "GPS Command/Report" (Min: 5Sec).
  3. The search range of a serial port was extended by 50.
  4. Only the available port was displayed on the drop down list of a serial port number.
  5. The maximum value, minimum value, and the mean value of UTC and the PC time difference 
     can have been displayed.
  6. The form minimization function at the time of Log play back was added.
  7. The compiler was changed into Delphi 2006 (Delphi for Win32).

Ver1.40 Oct. 2005
  1. To the extension name of a log file ".nmea" was added.
  2. The part of i.trek M3 and BT-338 of NMEA.INI was corrected in SiRFstarIII V.3.1.1 
     correspondence.
  3. Item name was modified(GSA: PRN->SV��GSV: PRN->SV#).
  4. The option which performs automatic re-opening of a serial port was added.
     A serial port is open, and when a non-signal state continues for 30 seconds, 
     re-opening of a serial port is performed.
  5. The message of a SiRF and UBX binary mode was displayed also on main form.
  6. The compiler was changed into Delphi 2005(Delphi for Win32).

Ver1.39 Jul. 2005
  1. It corrects the bug under second of time indication.
     Illegality indication under second of Local-time and  Fix-time was corrected.
  2. If it was in English mode, the sign "NSEW" of latitude longitude and the sign "EW" of 
     Magnetic Variation were displayed on the numerical end.
  3. Adding the command for Semsons i.Trek M3 to NMEA.INI(equality with GloablSat BT-338).
  4. In addition correction of detail.

Ver1.38 Jun. 2005
  1. When checksum has been attached to NMEA command, it tried not to add checksum doubly.
  2. It retained the display position of each Form, tried to reproduce to the next time.
     "GPS command/report" Form retains size.
  3. With respect to the right in Sky-plot speed(Km/H) Indication was added.
  4. The performance which searches the GPS connected port was added.
  5. Adding the command for GloablSat BT-338 to NMEA.INI.

Ver1.37 Mar. 2005
 1. Checksum addition performance to the UBX binary GPS command of ANTARIS was added.
 2. It enabled it to specify the baud rate after command sending out as the comment of the 
    GPS command.
 3. Error message inside principal to English was converted.
 4. Adding the command for GM-48-AT to NMEA.INI.
 5. 57,600bps was added to baud rate.
 6. When the number of digit under the second of UTC is other than 3 digit, conversion error 
    was corrected.
 7. Abolishing Trim() in the command character string, it tried to be able to transmit the 
    binary code of the first & end in the character string correctly.
 8. Adding the checksum addition performance to SiRF and UBX binary command.
 9. The manual was maintained.
10. In addition correction of detail.

Ver1.36 Feb. 2005.
 1. After sending GPS command, until it becomes fixed state, it added capture time display 
    function.
 2. It expanded the maximum number of records of GPS command to 100 commands in every type, 
    when command exceeds 100, it tried not to record new command.
 3. The fact that Enable initial value of the interval timer had become True was reset to 
    False.
 4. When the UTC time of a NMEA sentence did not contain a "." by six or more characters, 
    it was considered that the 7th character or subsequent ones was under a second.
 5. It enabled ON/OFF the time display of the NMEA sentence display line head of a 
    "GPS Command/Report".
 6. It tried to follow indication of date locale of Windows.
 7. Change to English mode was made possible.
 8. Specification of a font was enabled.
 9. Opposite direction replay to log playback, and step playback performance were added.
10. Difference of UTC time of RMC sentence was watched, the performance which indicates the 
    report in when there is a difference above designated second number was added from the 
    last time.
11. It made time difference of the local time and to be able to get name from OS.
12. Reversing, it adjusted polarity of time difference of the local time to Windows.
13. When "Sync Adj" value of option is blank, it tried not to revise.
14. Height of main form was compressed a little.
15. The individual correspondence of GM-38 was abolished.
16. In addition correction of detail.

 .... The middle is abbreviated ....

Ver1.00 Jun. 2000
  First editions.

Test code for Adafruit GPS modules using MTK driver
such as www.adafruit.com/products/660
Pick one up today at the Adafruit electronics shop 
and help support open source hardware & software! -ada
